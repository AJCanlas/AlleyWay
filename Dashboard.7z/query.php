<?php

	include "connect.php";
		
	function getBusiness($owner,$conn){
		$results = $conn->query("Select * from Business where owner_id=$owner");
		if ($results->num_rows > 0) {
			$data=$results;	
		    }else{
			$data=0;	
		}
	
		return $data;
	}
	
	function getFloor($owner,$bus,$conn){
		$results = $conn->query("Select Count(floor) as num from Data where owner_id=$owner and business_id=$bus");
			if ($results->num_rows > 0) {
    				while($row = $results->fetch_assoc()) {
        				$data=$row['num'];
    				}
			}
		return $data;
	}

		function getUnits($owner,$bus,$floor,$conn){
		$results = $conn->query("Select Count(unit) as num from Data where owner_id=$owner and business_id=$bus and floor=$floor");
			if ($results->num_rows > 0) {
    				while($row = $results->fetch_assoc()) {
        				$data=$row['num'];
    				}
			}
		return $data;
	}

?>
