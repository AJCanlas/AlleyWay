<?php
	$id=$_GET['id'];
	include"query.php";
	
	$flooractive = $unitactive = $subunitactive = $tenantactive = $bdata =$fdata = $floordata = "";	
	if(getBusiness($id,$conn)==0){
		$flooractive = $unitactive = $subunitactive = $tenantactive = "disabled";	
	}else{
			$resbus = getBusiness($id,$conn);
			while($row = $resbus->fetch_assoc()) {
			$bus = $row['business_id'];
			$bnaming = $row['business'];			
			$bdata .= "<option value='$bus'>$bnaming</option>";
			if(($floornum=getFloor($id,$bus,$conn))==0){
				$unitactive = $subunitactive = "disabled";	
			}else{

				for ($a = 1; $a <= $floornum; $a++){
					$fdata .= "<option value='".$bus."_".$a."'>$bnaming/Floor $a</option>";
									if(getUnits($id,$bus,$a,$conn)==0){
					 	$subunitactive = "disabled";	
				}
				}
			}
		}
	}

			$resbus = getBusiness($id,$conn);
			if ($resbus->num_rows > 0){
			while($row = $resbus->fetch_assoc()) {
			$bus = $row['business_id'];
			$bnaming = $row['business'];
			if(($floornum = getFloor($id,$bus,$conn))>0){
				for ($a = 1; $a <= $floornum; $a++){
					if(($Unitnum = getUnits($id,$bus,$a,$conn))>0){
				for ($x = 1; $x <= $Unitnum; $x++){
					
					$Unitdata .= "<div class='panel-group'><div class='panel panel-primary'><div class='panel-heading'><h4 class='panel-title'><a data-toggle='collapse' href='#Unit".$x."_"."$a"."_".$bus."'>Unit $x</a></h4></div><div id='Unit".$x."_"."$a"."_".$bus."' class='panel-collapse collapse'><div class='panel-body'>$</div></div></div></div>";
				}
			}
					$floordata .= "<div class='panel-group'><div class='panel panel-primary'><div class='panel-heading'><h4 class='panel-title'><a data-toggle='collapse' href='#floor$a"."_".$bus."'>Floor $a</a></h4></div><div id='floor$a"."_".$bus."' class='panel-collapse collapse'><div class='panel-body'>$Unitdata</div></div></div></div>";
				$Unitdata="";
				}
			}		
			$dashdatab .= "<div class='panel-group'><div class='panel panel-primary'><div class='panel-heading'><h4 class='panel-title'><a data-toggle='collapse' href='#bus$bus'>$bnaming</a></h4></div><div id='bus$bus' class='panel-collapse collapse'><div class='panel-body'>$floordata</div></div></div></div>";
			$floordata="";
			}
			}

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>AlleyWay</title>

 <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
  <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="">Alleyway</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#">Logout</a></li>
    </ul>
  </div>
</nav>
<section style="padding-top:7%">
</section>

  	<div class="col-lg-4">
		<div class="panel panel-primary">
  			<div class="panel-heading">Buissness</div>
  			<div class="panel-body">
				<?php echo $dashdatab;?>
			</div>
		</div>
	</div>
	<div class="col-lg-8">
		<div class="panel panel-primary" id="acc">
  			<div class="panel-heading">Dashboard</div>
  			<div class="panel-body">
				 <div class="btn-group btn-group-justified">
  					<a href="#Bus" class="btn btn-primary " data-toggle="collapse" >Add Buisness</a>
  					<a href="#Flo" class="btn btn-primary  <?php echo $flooractive?>" data-toggle="collapse" >Add Floor</a>
  					<a href="#Uni" class="btn btn-primary <?php echo $unitactive?>" data-toggle="collapse" >Add Units</a>
					<a href="#SUn" class="btn btn-primary <?php echo $subunitactive?>" data-toggle="collapse" >Add Sub Units</a>
					<a href="#Ten" class="btn btn-primary <?php echo $tenantactive?>" data-toggle="collapse" >Add Tenant</a>
					<a href="#Emp" class="btn btn-primary" data-toggle="collapse" >Add Employee</a>
				</div>
				
					<div id="Bus" class="panel-collapse collapse out">
						<div class="panel panel-default">
							<div class="panel-heading">Buisness</div>
  							<div class="panel-body">
								<form action="business.php?id=<?php echo $id?>" method="POST">
									 <div class="form-group">
  										<label for="bname">Business Name:</label>
 										<input type="text" class="form-control" id="bname" name="bname">
									</div>
									 <div class="form-group">
  										<label for="bdes">Business Description:</label>
 										<input type="textarea" class="form-control" id="bdes" name="bdes">
									</div>
									<button type="submit" class="btn btn-primary">Add Business</button>
								</form>
							</div>
						</div>
    					</div>
					<div id="Flo" class="panel-collapse collapse out">
						<div class="panel panel-default">
							<div class="panel-heading">Add Floor</div>
  							<div class="panel-body">
								<form action="floor.php?id=<?php echo $id?>" method="POST">
								    <div class="form-group">
      									<label for="busname">Buisness:</label>
      										<select class="form-control" id="busname" name="busname">
       											<?php echo $bdata;?>
      										</select>
								    </div>
								<button type="submit" class="btn btn-primary">Add Floor</button>
								</form>
							</div>
    						</div>
					</div>
					<div id="Uni" class="panel-collapse collapse out">
						<div class="panel panel-default">
							<div class="panel-heading">Add Units</div>
  							<div class="panel-body">
								<form action="floor.php?id=<?php echo $id?>" method="POST">
								    <div class="form-group">
      									<label for="floname">Floor:</label>
      										<select class="form-control" id="floname" name="floname">
       											<?php echo $fdata;?>
      										</select>
								    </div>
								<button type="submit" class="btn btn-primary">Add Unit</button>
								</form>
							</div>
						</div>
    					</div>
					<div id="SUn" class="panel-collapse collapse out">
						<div class="panel panel-default">
							<div class="panel-heading">Add Sub Units</div>
  							<div class="panel-body">
								
							</div>
						</div>
    					</div>
					<div id="Ten" class="panel-collapse collapse out">
						<div class="panel panel-default">
							<div class="panel-heading">Add Tenant</div>
  							<div class="panel-body">
								
							</div>
						</div>
    					</div>
					<div id="Emp" class="panel-collapse collapse out">
						<div class="panel panel-default">
							<div class="panel-heading">Add Employee</div>
  							<div class="panel-body">
								
							</div>
						</div>
    					</div>
				  </div>
			</div>
			
		</div>
	</div>



  </body>
</html>
