<?php
		
	$id = Null;
	$data = $_POST['floname'];
	$dats = explode("_",$data);
	$id = $_GET['id'];
	
	include "query.php";

	$unit = getUnit($id,$dats[0],$dats[1],$conn) + 1;
	$sql = "Insert into Data (business_id,floor,unit,owner_id) values($dats[0],$dats[1],$unit,$id)";
	$conn->query($sql);
	header("location:dashboard.php?id=$id");

?>
