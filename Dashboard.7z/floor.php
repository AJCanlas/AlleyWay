<?php
		
	$bname = $id = $bdes = Null;
	$bid = $_POST['busname'];
	$id = $_GET['id'];
	
	include "query.php";

	$floor = getFloor($id,$bid,$conn) + 1;
	$sql = "Insert into Data (business_id,floor,owner_id) values($bid,$floor,$id)";
	$conn->query($sql);
	header("location:dashboard.php?id=$id");

?>
