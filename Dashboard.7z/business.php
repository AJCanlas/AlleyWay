<?php
	$bname = $id = $bdes = Null;
	$bname = $_POST['bname'];
	$bdes = $_POST['bdes'];
	$id = $_GET['id'];
	
	include "connect.php";

	$sql = "Insert into Business (business,business_description,owner_id) values('$bname','$bdes',$id)";
	$conn->query($sql);
	$sql1 = "Select business_id from Business where business='$bname'";
	$result = $conn->query($sql1);
	if ($result->num_rows > 0) {
    	while($row = $result->fetch_assoc()) {
        	$bid=$row['business_id'];
    	}
	}
	$sql2 = "Insert into Data (business_id,owner_id) values($bid,$id)";
	$conn->query($sql2);	
	header("location:dashboard.php?id=$id");

?>
